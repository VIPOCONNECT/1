
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ canvas: document.querySelector('#bg') });

renderer.setSize(window.innerWidth, window.innerHeight);
camera.position.setZ(30);

// Light
const pointLight = new THREE.PointLight(0x00ffff);
pointLight.position.set(5, 5, 5);
scene.add(pointLight);
scene.add(new THREE.AmbientLight(0xffffff));

// Stars
function addStar() {
  const geometry = new THREE.SphereGeometry(0.2, 24, 24);
  const material = new THREE.MeshStandardMaterial({ color: 0x00ffff });
  const star = new THREE.Mesh(geometry, material);
  const [x, y, z] = Array(3).fill().map(() => THREE.MathUtils.randFloatSpread(100));
  star.position.set(x, y, z);
  scene.add(star);
}
Array(400).fill().forEach(addStar);

// Load 3D Model
const loader = new THREE.GLTFLoader();
loader.load('models/brain.glb', function(gltf) {
  const model = gltf.scene;
  model.scale.set(2, 2, 2);
  model.position.set(0, -5, 0);
  scene.add(model);
  animate(model);
}, undefined, function(error) {
  console.error(error);
});

function animate(model) {
  requestAnimationFrame(() => animate(model));
  model.rotation.y += 0.01;
  renderer.render(scene, camera);
}

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

gsap.from(".hero h2", { duration: 1.5, y: -50, opacity: 0, ease: "power4.out" });
gsap.from(".hero p", { duration: 1.5, y: 50, opacity: 0, delay: 0.5, ease: "power4.out" });
gsap.from(".btn-glow", { duration: 1.5, scale: 0, opacity: 0, delay: 1, ease: "elastic.out(1, 0.3)" });
