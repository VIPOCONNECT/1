# NeoAI GitHub Pages Ready

## מבנה פרויקט

1. `index.html` - קובץ ראשי HTML
2. `css/style.css` - עיצוב בסיסי
3. `js/script.js` - טעינת תלת מימד ואנימציות
4. `models/brain.glb` - מודל תלת מימדי של מוח AI
5. `images` - אייקונים PWA
6. `manifest.json` - מידע על האפליקציה
7. `sw.js` - Service Worker

להעלות ל-GitHub Pages:
- בחר את ענף `main` ושורש `/root`
- אחרי דקה תראה את האתר ב-`https://USERNAME.github.io/NeoAI`
